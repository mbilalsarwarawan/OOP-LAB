package com.company;


public class ContactManager {
    int friendCount;
    Contact [] friend;

    ContactManager()
    {
       this.friendCount=0;
        friend =new Contact[500];
    }
    void addFriend(Contact contact)
    {
        friend[friendCount]=contact;

        friendCount++;

    }
    Contact searchFriend(String name)
    {
        for(int i=0; i<friendCount;i++)
        {
            if(friend[i].getName().equals(name)){
                return friend[i];
            }
        }
        return null;
    }
}
