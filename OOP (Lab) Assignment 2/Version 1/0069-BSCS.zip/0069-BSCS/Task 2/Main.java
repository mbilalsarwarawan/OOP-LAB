package com.company;

import java.util.concurrent.Callable;

public class Main {

    public static void main(String[] args) {
        System.out.println("Name : Muhammad Bilal Awan");
        System.out.println("Roll no 0069-BSCS-2020 sec \"C\"\n\n\n");

     ContactManager myContact =new ContactManager();
     Contact Friend1=new Contact();
  Contact Friend2=new Contact();
     Friend1.newContact("Bilal","03201487846");
     Friend2.newContact("Ali","03000770078");
     myContact.addFriend(Friend1);
     myContact.addFriend(Friend2);
        Contact result =myContact.searchFriend("Ali");
        System.out.println(result.getName()+" "+result.getNumber());

    }
}
