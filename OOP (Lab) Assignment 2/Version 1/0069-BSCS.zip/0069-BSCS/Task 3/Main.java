package com.company;

import java.util.ArrayList;
import java.util.Collections;
import java.util.ListIterator;

public class Main {

    public static void main(String[] args) {
        // write your code here
        ArrayList<String> list = new ArrayList<String>();
        System.out.println("Name Muhammad Bilal Awan");
        System.out.println("Roll no 69-BSCS-20");


        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        list.add("E");
        list.add("F");
        list.add("H");

         for (int i=0 ;i<list.size();i++)
         {
             System.out.println(list.get(i));

         }

for (int i=0;i< list.size();i++)
{
    String add=list.get(i)+"+";
    list.add(i,add);
}

         Collections.reverse(list);
        for (int i=0 ;i<list.size();i++)
        {


            System.out.println(list.get(i));

        }
    }


}
