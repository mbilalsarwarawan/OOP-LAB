package com.company;

import java.util.List;
import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
	// write your code here
        String[] array = {"a", "b", "c", "d", "e"};



        List<String> list = Arrays.asList(array);
        System.out.println(list);

    }
}
