package com.company;

import java.util.ArrayList;

public class arrayToArrayList {
    ArrayList<String>list=new ArrayList<String>();

}
