package com.company;

public class Square extends Shape implements  Area{
    public double area;
    public double length;
    public Square(){
        super.setName("This is a square");
    }

    public void calculateArea(double length)
    {
        area= length*length;
    }
    public double getArea(){
        return area;
    }
}
