package com.company;

public class Circle extends Shape implements Area{
    public double area;
    public double radius;
    public Circle(){
        super.setName("This is a circle");
    }

    public void calculateArea(double radius)
    {
        area= 3.14*radius*radius;
    }
    public double getArea(){
        return area;
    }
}
