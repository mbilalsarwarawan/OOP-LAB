package com.company;

import java.util.concurrent.Callable;

public class Main {

    public static void main(String[] args) {
	// write your code here


        Sphere s1 =new Sphere();
        s1.calculateVolume(2);
        System.out.println(s1.getVolume());
        System.out.println(s1.getName());
        Square sq1 = new Square();
        sq1.calculateArea(2);
        System.out.println(sq1.getArea());

        CUbe c1 = new CUbe();
        c1.calculateVolume(2);
      System.out.println(c1.getName()+"\n"+c1.getVolume());

    }
}
