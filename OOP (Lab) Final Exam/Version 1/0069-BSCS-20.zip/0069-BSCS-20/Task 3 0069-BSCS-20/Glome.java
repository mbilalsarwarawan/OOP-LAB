package com.company;

public class Glome extends Shape implements Area,Volume {
    public double area;
    private double height;
    private double volume;
    public Glome(){
        super.setName("This is a glome");
    }


    public void calculateArea( double radius) {

        area =2*Math.PI*Math.PI*radius*radius*radius;
    }


    public double getArea() {
        return getArea();
    }

    public void calculateVolume(double radius,double height){


        volume=(0.5*Math.PI*Math.PI*radius*radius*radius*radius);
    }
    @Override
    public double getVolume() {
        return volume;
    }
}
