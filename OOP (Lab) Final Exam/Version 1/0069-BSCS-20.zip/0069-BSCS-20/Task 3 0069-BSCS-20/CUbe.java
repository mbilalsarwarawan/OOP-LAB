package com.company;

public class CUbe extends Square implements  Volume {
    private double volume;
    public CUbe(){
        super.setName("This is a Cube");
    }

    @Override
    public void calculateArea(double length) {
        super.area = 6*length*length*length*length*length*length;
    }

    @Override
    public double getArea() {
        return super.getArea();
    }

    public void calculateVolume(double length){


        volume=length*length*length;
    }
    @Override
    public double getVolume() {
        return volume;
    }

}
