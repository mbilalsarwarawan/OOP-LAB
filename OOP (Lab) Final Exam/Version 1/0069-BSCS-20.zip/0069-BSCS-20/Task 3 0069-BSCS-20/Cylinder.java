package com.company;

public class Cylinder extends Shape implements Volume , Area{
    public double area;

    private double volume;
    public Cylinder(){
        super.setName("This is a Cylinder");
    }


    public void calculateArea( double radius ) {

        area =4*Math.PI*radius*radius;
    }


    public double getArea() {
        return getArea();
    }

    public void calculateVolume(double radius,double height){


        volume=Math.PI*radius*radius*height;
    }
    @Override
    public double getVolume() {
        return volume;
    }

}
