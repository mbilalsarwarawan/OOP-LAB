package com.company;

public interface Area {
    public double getArea();
}
