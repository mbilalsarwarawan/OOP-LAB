package com.company;

public interface Volume {
    public double getVolume();
}
