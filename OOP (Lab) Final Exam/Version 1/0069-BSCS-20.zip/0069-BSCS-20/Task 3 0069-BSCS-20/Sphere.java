package com.company;
import java.lang.Math;
public class Sphere extends Circle implements Volume{
    private double volume;
    public Sphere(){
        super.setName("This is a sphere");
    }

    @Override
    public void calculateArea(double radius) {
       area = 4*3.14*radius*radius;
    }

    @Override
    public double getArea() {
        return super.getArea();
    }

    public void calculateVolume(double radius){


        volume=(1.333)*Math.PI*(radius*radius*radius);
    }
    @Override
    public double getVolume() {
        return volume;
    }

}
