package com.company;

public class Doctor {

    private String doctorName;
    private String doctorCnic;
    private String doctorMobile;
    private int doctorId;
    private generate_id Id= new generate_id();
    public Doctor(String doctorName, String doctorCnic, String doctorMobile) {
        this.doctorId = Id.gen_id();
        this.doctorName = doctorName;
        this.doctorCnic = doctorCnic;
        this.doctorMobile = doctorMobile;
    }
 public Doctor(){
     this.doctorId = Id.gen_id();
     this.doctorName = null;
     this.doctorCnic = null;
     this.doctorMobile =  null;
 }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getDoctorCnic() {
        return doctorCnic;
    }

    public void setDoctorCnic(String doctorCnic) {
        this.doctorCnic = doctorCnic;
    }

    public String getDoctorMobile() {
        return doctorMobile;
    }


    public void display(){
        System.out.println("The name of the doctor is "+doctorName);
        System.out.println("The id of the doctor is "+ doctorId);
        System.out.println("The Cnic number of the doctor id is "+ doctorCnic);
        System.out.println("The mobile number of the doctor is "+doctorMobile);
    }

}
