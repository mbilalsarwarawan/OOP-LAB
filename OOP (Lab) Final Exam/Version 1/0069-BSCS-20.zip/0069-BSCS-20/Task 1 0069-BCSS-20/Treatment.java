package com.company;

public class Treatment {
    private String treatmentName;
 private generate_id ID=new generate_id() ;
    private String treatmentPrice;
    private  int treatmentID;


    public Treatment(String treatmentName, String treatmentPrice) {
        this.treatmentName = treatmentName;
        this.treatmentID = ID.gen_id();
        this.treatmentPrice = treatmentPrice;
    }

    public Treatment() {
    }

    public String getTreatmentName() {
        return treatmentName;
    }

    public void setTreatmentName(String treatmentName) {
        this.treatmentName = treatmentName;
    }

    public String getTreatmentPrice() {
        return treatmentPrice;
    }

    public int getTreatmentID() {
        return treatmentID;
    }

    public void setTreatmentPrice(String treatmentPrice) {
        this.treatmentPrice = treatmentPrice;
    }
    public void display(){
        System.out.println("The treatment name is "+treatmentName);
        System.out.println("The treatment price is  "+ treatmentPrice);
        System.out.println("The treatment id is "+ treatmentID);

    }

}
