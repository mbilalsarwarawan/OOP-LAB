package com.company;

public class Appointment  {
    private String appDate;
    private String appTime;
    private int appID;
    private generate_id Id=new generate_id() ;

    public Appointment() {
    }

    public Appointment(String appDate, String appTime) {
        this.appDate = appDate;
        this.appTime = appTime;
        this.appID =  Id.gen_id();
    }

    public String getAppDate() {
        return appDate;
    }

    public void setAppDate(String appDate) {
        this.appDate = appDate;
    }

    public String getAppTime() {
        return appTime;
    }

    public void setAppTime(String appTime) {
        this.appTime = appTime;
    }

    public int getAppID() {
        return appID;
    }

    public void display(){
        System.out.println("The appointment date is "+appDate);
        System.out.println("The appointment Time is  "+ appTime);
        System.out.println("The appointment id is "+ appID);

    }

}
