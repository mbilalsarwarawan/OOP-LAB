package com.company;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class generate_id {
    private Random rand = new Random();
    private List<Integer> generated_num = new ArrayList<Integer>();

    public int gen_id() {
        int id;
        id = rand.nextInt(9999) + 1;
        while(generated_num.contains(id)) {
            id = rand.nextInt(9999) + 1;
        }
        generated_num.add(id);
        return id;
    }
}
