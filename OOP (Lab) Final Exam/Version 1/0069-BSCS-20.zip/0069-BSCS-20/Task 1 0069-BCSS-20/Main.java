package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Doctor d1 =new Doctor("Bilal","2323-23232-23","0320-1293890");
        Patient p1 =new Patient("Ali","23233-232323-2","0324-9404242");
      Appointment ap1 =new Appointment("20-3-2022","10pm");
      Treatment t1= new Treatment("Flue","RS 1212");


        ap1.display();
        t1.display();
        d1.display();
        p1.display();
    }
}
