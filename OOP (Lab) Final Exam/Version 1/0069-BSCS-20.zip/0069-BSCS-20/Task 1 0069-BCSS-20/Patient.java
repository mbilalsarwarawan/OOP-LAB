package com.company;

public class Patient {
    private String patientName;
    private String patientCnic;
    private String patientMobile;
    private int patientId;
    private generate_id Id= new generate_id();


    public Patient(String patientName, String patientCnic, String patientMobile) {
        this.patientName = patientName;
        this.patientCnic = patientCnic;
        this.patientMobile = patientMobile;
        this.patientId = Id.gen_id();
    }
    public Patient() {
        this.patientName = null;
        this.patientCnic = null;
        this.patientMobile = null;
        this.patientId = patientId;
    }

    public int getPatientId() {
        return patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getPatientCnic() {
        return patientCnic;
    }

    public void setPatientCnic(String patientCnic) {
        this.patientCnic = patientCnic;
    }

    public String getPatientMobile() {
        return patientMobile;
    }

    public void setPatientMobile(String patientMobile) {
        this.patientMobile = patientMobile;
    }
    public void display(){
        System.out.println("The name of the Patient is "+patientName);
        System.out.println("The id of the Patient is "+ patientId);
        System.out.println("The Cnic number of the Patient id is "+ patientCnic);
        System.out.println("The mobile number of the Patient is "+patientMobile);
    }

}
