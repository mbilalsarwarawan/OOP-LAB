package com.company;

public class Herbivores extends  Animal{
    public Herbivores(){
        System.out.println("I am a Herbivore");
    }
    public void eat() {

        System.out.println("I can eat grass only");
    }

    @Override
    public void drink() {
        System.out.println("I can drink");
    }
    public void walk(){
        System.out.println("I can walk");
    }
}
