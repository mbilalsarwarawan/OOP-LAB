package com.company;

public abstract class Animal{

    public abstract void  eat();
    public abstract void drink();
    public abstract void  walk();
}
