package com.company;

import java.util.concurrent.Callable;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Omnivores o1 = new Omnivores();
        o1.eat();
        o1.drink();
        o1.walk();
        System.out.println("\n");
        Carnivores c1 =new Carnivores();
        c1.eat();
        c1.drink();
        c1.walk();
        System.out.println("\n");
        Herbivores h1 = new Herbivores();
        h1.eat();
        h1.drink();
        h1.walk();


            }
        }



