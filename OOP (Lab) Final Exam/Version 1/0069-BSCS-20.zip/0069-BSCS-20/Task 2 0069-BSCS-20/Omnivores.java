package com.company;

public class Omnivores extends Animal{
    public Omnivores(){
        System.out.println("I am a Omnivore");
    }

    @Override
    public void eat() {

        System.out.println("I can eat grass and meat");
    }
    public void kill(){
        System.out.println("I can Kill another animal ");
    }

    @Override
    public void drink() {
        System.out.println("I can drink");
    }
    public void walk(){
        System.out.println("I can walk");
    }
}
