package com.company;

public class Carnivores extends Animal{
    public Carnivores(){
        System.out.println("I am a Herbivore");
    }
    public void eat() {
        System.out.println("I am a Omnivore");
        System.out.println("I can meat only");
    }
    public void kill(){
        System.out.println("I can Kill another animal ");
    }

    @Override
    public void drink() {
        System.out.println("I can drink");
    }
    public void walk(){
        System.out.println("I can walk");
    }
}
